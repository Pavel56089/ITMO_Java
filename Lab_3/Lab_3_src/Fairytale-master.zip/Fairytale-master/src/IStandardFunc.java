public interface IStandardFunc {
    public int hashCode();
    public String toString();
    public boolean equals(Object obj);
}
