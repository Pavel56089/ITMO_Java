import java.util.ArrayList;

public interface IBunch {
    void add(AFlower f);
    ArrayList<AFlower> getFlowers();
}
