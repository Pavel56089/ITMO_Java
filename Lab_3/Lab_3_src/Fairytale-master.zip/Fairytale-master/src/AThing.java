abstract class AThing {
    private String Type;
    AThing(String s) {
        Type = s;
    }
    String getType() {
        return Type;
    }
}
