public class Place extends APlace {
    Place(String s) {
        super(s);
    }
}
