abstract class APlace {
    private String PlaceS;
    APlace(String s) {
        PlaceS = s;
    }

    String getPlace() {
        return PlaceS;
    }
}
