public class Thing extends AThing {
    Thing(String s) {
        super(s);
    }
}
