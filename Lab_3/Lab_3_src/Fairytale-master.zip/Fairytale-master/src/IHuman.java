public interface IHuman {
    void walk(APlace h);
    String getName();
}
